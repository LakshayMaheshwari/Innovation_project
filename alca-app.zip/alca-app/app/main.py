from fastapi import FastAPI
from app.agents import load_llm
from app.planner import goal_planner
from app.decision_agent import adapt_plan
from app.memory import store_state, fetch_user_data

app = FastAPI()
llm = load_llm()

@app.post("/plan")
def create_plan(user_goal: str):
    plan = goal_planner(llm, user_goal)
    return {"plan": plan}

@app.post("/log")
def log_day(user_id: str, day: int, steps: int, sleep: int, feedback: str):
    store_state(user_id, day, steps, sleep, feedback)
    return {"status": "saved"}

@app.get("/adapt")
def adapt(user_id: str):
    data = fetch_user_data(user_id)
    decision = adapt_plan(llm, data)
    return {"adapted_plan": decision}
