import sqlite3

conn = sqlite3.connect("user_memory.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS user_state (
    user_id TEXT,
    day INTEGER,
    steps INTEGER,
    sleep INTEGER,
    feedback TEXT
)
""")
conn.commit()

def store_state(user_id, day, steps, sleep, feedback):
    cursor.execute(
        "INSERT INTO user_state VALUES (?, ?, ?, ?, ?)",
        (user_id, day, steps, sleep, feedback)
    )
    conn.commit()

def fetch_user_data(user_id):
    cursor.execute(
        "SELECT * FROM user_state WHERE user_id = ?",
        (user_id,)
    )
    return cursor.fetchall()
