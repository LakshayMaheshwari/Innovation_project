from langchain_core.prompts import PromptTemplate

def adapt_plan(llm, user_data):
    prompt = PromptTemplate(
        input_variables=["data"],
        template="""
        Given the user's recent data:
        {data}

        Reason about:
        1. Why goals were missed or achieved
        2. Decide adjustments
        3. Output next-day plan

        Explain reasoning briefly.
        """
    )
    chain = prompt | llm
    return chain.invoke({"data": user_data})
