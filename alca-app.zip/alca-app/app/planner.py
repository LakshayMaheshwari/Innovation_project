from langchain_core.prompts import PromptTemplate

def goal_planner(llm, user_goal):
    prompt = PromptTemplate(
        input_variables=["goal"],
        template="""
        User goal: {goal}
        Break this into a 7-day fitness and lifestyle plan.
        Keep it safe and non-medical.
        """
    )
    chain = prompt | llm
    return chain.invoke({"goal": user_goal})
