from pydantic import BaseModel, Field
from typing import Optional, List
from enum import Enum
from datetime import datetime


# -------------------------------
# ENUMS (Controlled vocabularies)
# -------------------------------

class IntensityLevel(str, Enum):
    low = "low"
    medium = "medium"
    high = "high"


class MoodType(str, Enum):
    stressed = "stressed"
    neutral = "neutral"
    energetic = "energetic"
    tired = "tired"


# -------------------------------
# USER PROFILE MODEL
# -------------------------------

class UserProfile(BaseModel):
    user_id: str = Field(..., example="user_001")
    age: Optional[int] = Field(None, ge=10, le=100)
    height_cm: Optional[float] = Field(None, gt=50)
    weight_kg: Optional[float] = Field(None, gt=20)
    activity_level: Optional[str] = Field(
        None, example="sedentary / moderate / active"
    )
    created_at: datetime = Field(default_factory=datetime.utcnow)


# -------------------------------
# GOAL DEFINITION MODEL
# -------------------------------

class UserGoal(BaseModel):
    user_id: str = Field(..., example="user_001")
    goal_description: str = Field(
        ..., example="Lose 3 kg in 2 months"
    )
    duration_days: int = Field(..., gt=1, le=365)
    priority: Optional[int] = Field(
        1, description="1 = highest priority"
    )
    created_at: datetime = Field(default_factory=datetime.utcnow)


# -------------------------------
# DAILY ACTIVITY LOG
# -------------------------------

class DailyLog(BaseModel):
    user_id: str
    day: int = Field(..., ge=1)
    steps: int = Field(..., ge=0)
    sleep_hours: float = Field(..., ge=0, le=24)
    mood: Optional[MoodType]
    feedback: Optional[str]
    log_time: datetime = Field(default_factory=datetime.utcnow)


# -------------------------------
# AGENT OBSERVATION MODEL
# -------------------------------

class AgentObservation(BaseModel):
    user_id: str
    recent_logs: List[DailyLog]
    missed_goals: Optional[bool] = False
    notes: Optional[str]


# -------------------------------
# ADAPTED PLAN OUTPUT (AGENT RESPONSE)
# -------------------------------

class AdaptedPlan(BaseModel):
    reasoning: str = Field(
        ..., example="User had low sleep, reducing intensity"
    )
    next_day_plan: str = Field(
        ..., example="30 min walk + light stretching"
    )
    intensity: IntensityLevel
    motivation_message: Optional[str]


# -------------------------------
# API RESPONSE MODELS
# -------------------------------

class PlanResponse(BaseModel):
    user_id: str
    weekly_plan: str
    generated_at: datetime = Field(default_factory=datetime.utcnow)


class StatusResponse(BaseModel):
    status: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
