import streamlit as st
import requests

st.title("Adaptive Lifestyle Coach Agent")

goal = st.text_input("Enter your fitness goal")
if st.button("Create Plan"):
    res = requests.post("http://localhost:8501/plan", params={"user_goal": goal})
    st.write(res.json())

st.subheader("Daily Log")
user_id = st.text_input("User ID")
steps = st.number_input("Steps")
sleep = st.number_input("Sleep Hours")
feedback = st.text_input("How was your day?")

if st.button("Submit Log"):
    requests.post(
        "http://localhost:8501/log",
        params={
            "user_id": user_id,
            "day": 1,
            "steps": steps,
            "sleep": sleep,
            "feedback": feedback
        }
    )

if st.button("Adapt Plan"):
    res = requests.get("http://localhost:8501/adapt", params={"user_id": user_id})
    st.write(res.json())
